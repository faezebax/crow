/*
 *  Copyright © 2018-2019 Hennadii Chernyshchyk <genaloner@gmail.com>
 *
 *  This file is part of QOnlineTranslator.
 *
 *  QOnlineTranslator is free library; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a get of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "qonlinetranslator.h"
#include "qonlinetts.h"

#include <QStateMachine>
#include <QFinalState>
#include <QMediaPlayer>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonObject>
#include <QNetworkReply>

QString QOnlineTranslator::s_yandexKey; // The key that is parsed from the web version to get the translation using the API

const QMap<QOnlineTranslator::Language, QString> QOnlineTranslator::s_languageCodes = {
    {Auto, QStringLiteral("auto")},
    {Afrikaans, QStringLiteral("af")},
    {Albanian, QStringLiteral("sq")},
    {Amharic, QStringLiteral("am")},
    {Arabic, QStringLiteral("ar")},
    {Armenian, QStringLiteral("hy")},
    {Azerbaijani, QStringLiteral("az")},
    {Bashkir, QStringLiteral("ba")},
    {Basque, QStringLiteral("eu")},
    {Belarusian, QStringLiteral("be")},
    {Bengali, QStringLiteral("bn")},
    {Bosnian, QStringLiteral("bs")},
    {Bulgarian, QStringLiteral("bg")},
    {Cantonese, QStringLiteral("yue")},
    {Catalan, QStringLiteral("ca")},
    {Cebuano, QStringLiteral("ceb")},
    {Chichewa, QStringLiteral("ny")},
    {Corsican, QStringLiteral("co")},
    {Croatian, QStringLiteral("hr")},
    {Czech, QStringLiteral("cs")},
    {Danish, QStringLiteral("da")},
    {Dutch, QStringLiteral("nl")},
    {English, QStringLiteral("en")},
    {Esperanto, QStringLiteral("eo")},
    {Estonian, QStringLiteral("et")},
    {Fijian, QStringLiteral("fj")},
    {Filipino, QStringLiteral("fil")},
    {Finnish, QStringLiteral("fi")},
    {French, QStringLiteral("fr")},
    {Frisian, QStringLiteral("fy")},
    {Galician, QStringLiteral("gl")},
    {Georgian, QStringLiteral("ka")},
    {German, QStringLiteral("de")},
    {Greek, QStringLiteral("el")},
    {Gujarati, QStringLiteral("gu")},
    {HaitianCreole, QStringLiteral("ht")},
    {Hausa, QStringLiteral("ha")},
    {Hawaiian, QStringLiteral("haw")},
    {Hebrew, QStringLiteral("he")},
    {HillMari, QStringLiteral("mrj")},
    {Hindi, QStringLiteral("hi")},
    {Hmong, QStringLiteral("hmn")},
    {Hungarian, QStringLiteral("hu")},
    {Icelandic, QStringLiteral("is")},
    {Igbo, QStringLiteral("ig")},
    {Indonesian, QStringLiteral("id")},
    {Irish, QStringLiteral("ga")},
    {Italian, QStringLiteral("it")},
    {Japanese, QStringLiteral("ja")},
    {Javanese, QStringLiteral("jw")},
    {Kannada, QStringLiteral("kn")},
    {Kazakh, QStringLiteral("kk")},
    {Khmer, QStringLiteral("km")},
    {Klingon, QStringLiteral("tlh")},
    {KlingonPlqaD, QStringLiteral("tlh-Qaak")},
    {Korean, QStringLiteral("ko")},
    {Kurdish, QStringLiteral("ku")},
    {Kyrgyz, QStringLiteral("ky")},
    {Lao, QStringLiteral("lo")},
    {Latin, QStringLiteral("la")},
    {Latvian, QStringLiteral("lv")},
    {LevantineArabic, QStringLiteral("apc")},
    {Lithuanian, QStringLiteral("lt")},
    {Luxembourgish, QStringLiteral("lb")},
    {Macedonian, QStringLiteral("mk")},
    {Malagasy, QStringLiteral("mg")},
    {Malay, QStringLiteral("ms")},
    {Malayalam, QStringLiteral("ml")},
    {Maltese, QStringLiteral("mt")},
    {Maori, QStringLiteral("mi")},
    {Marathi, QStringLiteral("mr")},
    {Mari, QStringLiteral("mhr")},
    {Mongolian, QStringLiteral("mn")},
    {Myanmar, QStringLiteral("my")},
    {Nepali, QStringLiteral("ne")},
    {Norwegian, QStringLiteral("no")},
    {Papiamento, QStringLiteral("pap")},
    {Pashto, QStringLiteral("ps")},
    {Persian, QStringLiteral("fa")},
    {Polish, QStringLiteral("pl")},
    {Portuguese, QStringLiteral("pt")},
    {Punjabi, QStringLiteral("pa")},
    {QueretaroOtomi, QStringLiteral("otq")},
    {Romanian, QStringLiteral("ro")},
    {Russian, QStringLiteral("ru")},
    {Samoan, QStringLiteral("sm")},
    {ScotsGaelic, QStringLiteral("gd")},
    {SerbianCyrillic, QStringLiteral("sr-Cyrl")},
    {SerbianLatin, QStringLiteral("sr-Latin")},
    {Sesotho, QStringLiteral("st")},
    {Shona, QStringLiteral("sn")},
    {SimplifiedChinese, QStringLiteral("zh-CN")},
    {Sindhi, QStringLiteral("sd")},
    {Sinhala, QStringLiteral("si")},
    {Slovak, QStringLiteral("sk")},
    {Slovenian, QStringLiteral("sl")},
    {Somali, QStringLiteral("so")},
    {Spanish, QStringLiteral("es")},
    {Sundanese, QStringLiteral("su")},
    {Swahili, QStringLiteral("sw")},
    {Swedish, QStringLiteral("sv")},
    {Tagalog, QStringLiteral("tl")},
    {Tahitian, QStringLiteral("ty")},
    {Tajik, QStringLiteral("tg")},
    {Tamil, QStringLiteral("ta")},
    {Tatar, QStringLiteral("tt")},
    {Telugu, QStringLiteral("te")},
    {Thai, QStringLiteral("th")},
    {Tongan, QStringLiteral("to")},
    {TraditionalChinese, QStringLiteral("zh-TW")},
    {Turkish, QStringLiteral("tr")},
    {Udmurt, QStringLiteral("udm")},
    {Ukrainian, QStringLiteral("uk")},
    {Urdu, QStringLiteral("ur")},
    {Uzbek, QStringLiteral("uz")},
    {Vietnamese, QStringLiteral("vi")},
    {Welsh, QStringLiteral("cy")},
    {Xhosa, QStringLiteral("xh")},
    {Yiddish, QStringLiteral("yi")},
    {Yoruba, QStringLiteral("yo")},
    {YucatecMaya, QStringLiteral("yua")},
    {Zulu, QStringLiteral("zu")}
};

QOnlineTranslator::QOnlineTranslator(QObject *parent)
    : QObject(parent)
    , m_stateMachine(new QStateMachine(this))
    , m_networkManager(new QNetworkAccessManager(this))
{
    connect(m_stateMachine, &QStateMachine::finished, this, &QOnlineTranslator::finished);
    connect(m_stateMachine, &QStateMachine::stopped, this, &QOnlineTranslator::finished);
}

void QOnlineTranslator::translate(const QString &text, Engine engine, Language translationLang, Language sourceLang, Language uiLang)
{
    abort();
    resetData();

    m_onlyDetectLanguage = false;
    m_source = text;
    m_sourceLang = sourceLang;

    if (translationLang == Auto)
        m_translationLang = language(QLocale());
    else
        m_translationLang = translationLang;

    if (uiLang == Auto)
        m_uiLang = language(QLocale());
    else
        m_uiLang = uiLang;

    // Check if choosed languages are supported by the engine
    if (!isSupportTranslation(engine, m_sourceLang)) {
        resetData(ParametersError, tr("Selected source language %1 is not supported for %2")
                  .arg(languageString(m_sourceLang), QMetaEnum::fromType<Engine>().valueToKey(engine)));
        emit finished();
        return;
    }
    if (!isSupportTranslation(engine, m_translationLang)) {
        resetData(ParametersError, tr("Selected translation language %1 is not supported for %2")
                  .arg(languageString(m_translationLang), QMetaEnum::fromType<Engine>().valueToKey(engine)));
        emit finished();
        return;
    }
    if (!isSupportTranslation(engine, m_uiLang)) {
        resetData(ParametersError, tr("Selected ui language %1 is not supported for %2")
                  .arg(languageString(m_uiLang), QMetaEnum::fromType<Engine>().valueToKey(engine)));
        emit finished();
        return;
    }

    switch (engine) {
    case Google:
        buildGoogleStateMachine();
        break;
    case Yandex:
        buildYandexStateMachine();
        break;
    case Bing:
        buildBingStateMachine();
        break;
    }

    m_stateMachine->start();
}

void QOnlineTranslator::detectLanguage(const QString &text, Engine engine)
{
    abort();
    resetData();

    m_onlyDetectLanguage = true;
    m_source = text;
    m_sourceLang = Auto;
    m_translationLang = English;
    m_uiLang = language(QLocale());

    switch (engine) {
    case Google:
        buildGoogleDetectStateMachine();
        break;
    case Yandex:
        buildYandexDetectStateMachine();
        break;
    case Bing:
        buildBingDetectStateMachine();
    }

    m_stateMachine->start();
}

void QOnlineTranslator::abort()
{
    if (m_currentReply != nullptr)
        m_currentReply->abort();
}

bool QOnlineTranslator::isRunning() const
{
    return m_stateMachine->isRunning();
}

QString QOnlineTranslator::source() const
{
    return m_source;
}

QString QOnlineTranslator::sourceTranslit() const
{
    return m_sourceTranslit;
}

QString QOnlineTranslator::sourceTranscription() const
{
    return m_sourceTranscription;
}

QString QOnlineTranslator::sourceLanguageString() const
{
    return languageString(m_sourceLang);
}

QOnlineTranslator::Language QOnlineTranslator::sourceLanguage() const
{
    return m_sourceLang;
}

QString QOnlineTranslator::translation() const
{
    return m_translation;
}

QString QOnlineTranslator::translationTranslit() const
{
    return m_translationTranslit;
}

QString QOnlineTranslator::translationLanguageString() const
{
    return languageString(m_translationLang);
}

QOnlineTranslator::Language QOnlineTranslator::translationLanguage() const
{
    return m_translationLang;
}

QMap<QString, QVector<QOnlineTranslator::QOption>> QOnlineTranslator::translationOptions() const
{
    return m_translationOptions;
}

QMap<QString, QVector<QOnlineTranslator::QExample>> QOnlineTranslator::examples() const
{
    return m_examples;
}

QString QOnlineTranslator::errorString() const
{
    return m_errorString;
}

QOnlineTranslator::TranslationError QOnlineTranslator::error() const
{
    return m_error;
}

QString QOnlineTranslator::languageString(Language lang)
{
    switch (lang) {
    case Auto:
        return tr("Automatically detect");
    case Afrikaans:
        return tr("Afrikaans");
    case Albanian:
        return tr("Albanian");
    case Amharic:
        return tr("Amharic");
    case Arabic:
        return tr("Arabic");
    case Armenian:
        return tr("Armenian");
    case Azerbaijani:
        return tr("Azeerbaijani");
    case Basque:
        return tr("Basque");
    case Bashkir:
        return tr("Bashkir");
    case Belarusian:
        return tr("Belarusian");
    case Bengali:
        return tr("Bengali");
    case Bosnian:
        return tr("Bosnian");
    case Bulgarian:
        return tr("Bulgarian");
    case Catalan:
        return tr("Catalan");
    case Cantonese:
        return tr("Cantonese");
    case Cebuano:
        return tr("Cebuano");
    case SimplifiedChinese:
        return tr("Chinese (Simplified)");
    case TraditionalChinese:
        return tr("Chinese (Traditional)");
    case Corsican:
        return tr("Corsican");
    case Croatian:
        return tr("Croatian");
    case Czech:
        return tr("Czech");
    case Danish:
        return tr("Danish");
    case Dutch:
        return tr("Dutch");
    case English:
        return tr("English");
    case Esperanto:
        return tr("Esperanto");
    case Estonian:
        return tr("Estonian");
    case Fijian:
        return tr("Fijian");
    case Filipino:
        return tr("Filipino");
    case Finnish:
        return tr("Finnish");
    case French:
        return tr("French");
    case Frisian:
        return tr("Frisian");
    case Galician:
        return tr("Galician");
    case Georgian:
        return tr("Georgian");
    case German:
        return tr("German");
    case Greek:
        return tr("Greek");
    case Gujarati:
        return tr("Gujarati");
    case HaitianCreole:
        return tr("Haitian Creole");
    case Hausa:
        return tr("Hausa");
    case Hawaiian:
        return tr("Hawaiian");
    case Hebrew:
        return tr("Hebrew");
    case HillMari:
        return tr("Hill Mari");
    case Hindi:
        return tr("Hindi");
    case Hmong:
        return tr("Hmong");
    case Hungarian:
        return tr("Hungarian");
    case Icelandic:
        return tr("Icelandic");
    case Igbo:
        return tr("Igbo");
    case Indonesian:
        return tr("Indonesian");
    case Irish:
        return tr("Irish");
    case Italian:
        return tr("Italian");
    case Japanese:
        return tr("Japanese");
    case Javanese:
        return tr("Javanese");
    case Kannada:
        return tr("Kannada");
    case Kazakh:
        return tr("Kazakh");
    case Khmer:
        return tr("Khmer");
    case Klingon:
        return tr("Klingon");
    case KlingonPlqaD:
        return tr("Klingon (PlqaD)");
    case Korean:
        return tr("Korean");
    case Kurdish:
        return tr("Kurdish");
    case Kyrgyz:
        return tr("Kyrgyz");
    case Lao:
        return tr("Lao");
    case Latin:
        return tr("Latin");
    case Latvian:
        return tr("Latvian");
    case LevantineArabic:
        return tr("Levantine Arabic");
    case Lithuanian:
        return tr("Lithuanian");
    case Luxembourgish:
        return tr("Luxembourgish");
    case Macedonian:
        return tr("Macedonian");
    case Malagasy:
        return tr("Malagasy");
    case Malay:
        return tr("Malay");
    case Malayalam:
        return tr("Malayalam");
    case Maltese:
        return tr("Maltese");
    case Maori:
        return tr("Maori");
    case Marathi:
        return tr("Marathi");
    case Mari:
        return tr("Mari");
    case Mongolian:
        return tr("Mongolian");
    case Myanmar:
        return tr("Myanmar");
    case Nepali:
        return tr("Nepali");
    case Norwegian:
        return tr("Norwegian");
    case Chichewa:
        return tr("Chichewa");
    case Papiamento:
        return tr("Papiamento");
    case Pashto:
        return tr("Pashto");
    case Persian:
        return tr("Persian");
    case Polish:
        return tr("Polish");
    case Portuguese:
        return tr("Portuguese");
    case Punjabi:
        return tr("Punjabi");
    case QueretaroOtomi:
        return tr("Queretaro Otomi");
    case Romanian:
        return tr("Romanian");
    case Russian:
        return tr("Russian");
    case Samoan:
        return tr("Samoan");
    case ScotsGaelic:
        return tr("Scots Gaelic");
    case SerbianCyrillic:
        return tr("Serbian (Cyrillic)");
    case SerbianLatin:
        return tr("Serbian (Latin)");
    case Sesotho:
        return tr("Sesotho");
    case Shona:
        return tr("Shona");
    case Sindhi:
        return tr("Sindhi");
    case Sinhala:
        return tr("Sinhala");
    case Slovak:
        return tr("Slovak");
    case Slovenian:
        return tr("Slovenian");
    case Somali:
        return tr("Somali");
    case Spanish:
        return tr("Spanish");
    case Sundanese:
        return tr("Sundanese");
    case Swahili:
        return tr("Swahili");
    case Swedish:
        return tr("Swedish");
    case Tagalog:
        return tr("Tagalog");
    case Tahitian:
        return tr("Tahitian");
    case Tajik:
        return tr("Tajik");
    case Tamil:
        return tr("Tamil");
    case Tatar:
        return tr("Tatar");
    case Telugu:
        return tr("Telugu");
    case Thai:
        return tr("Thai");
    case Tongan:
        return tr("Tongan");
    case Turkish:
        return tr("Turkish");
    case Udmurt:
        return tr("Udmurt");
    case Ukrainian:
        return tr("Ukrainian");
    case Urdu:
        return tr("Urdu");
    case Uzbek:
        return tr("Uzbek");
    case Vietnamese:
        return tr("Vietnamese");
    case Welsh:
        return tr("Welsh");
    case Xhosa:
        return tr("Xhosa");
    case Yiddish:
        return tr("Yiddish");
    case Yoruba:
        return tr("Yoruba");
    case YucatecMaya:
        return tr("Yucatec Maya");
    case Zulu:
        return tr("Zulu");
    default:
        return QString();
    }
}

QString QOnlineTranslator::languageCode(Language lang)
{
    return s_languageCodes.value(lang);
}

QOnlineTranslator::Language QOnlineTranslator::language(const QLocale &locale)
{
    switch (locale.language()) {
    case QLocale::Afrikaans:
        return Afrikaans;
    case QLocale::Albanian:
        return Albanian;
    case QLocale::Amharic:
        return Amharic;
    case QLocale::Arabic:
        return Arabic;
    case QLocale::Armenian:
        return Armenian;
    case QLocale::Azerbaijani:
        return Azerbaijani;
    case QLocale::Basque:
        return Basque;
    case QLocale::Belarusian:
        return Belarusian;
    case QLocale::Bengali:
        return Bengali;
    case QLocale::Bosnian:
        return Bosnian;
    case QLocale::Bulgarian:
        return Bulgarian;
    case QLocale::Catalan:
        return Catalan;
    case QLocale::Chinese:
        return SimplifiedChinese;
    case QLocale::LiteraryChinese:
        return TraditionalChinese;
    case QLocale::Corsican:
        return Corsican;
    case QLocale::Croatian:
        return Croatian;
    case QLocale::Czech:
        return Czech;
    case QLocale::Danish:
        return Danish;
    case QLocale::Dutch:
        return Dutch;
    case QLocale::Esperanto:
        return Esperanto;
    case QLocale::Estonian:
        return Estonian;
    case QLocale::Finnish:
        return Finnish;
    case QLocale::French:
        return French;
    case QLocale::Frisian:
        return Frisian;
    case QLocale::Galician:
        return Galician;
    case QLocale::Georgian:
        return Georgian;
    case QLocale::German:
        return German;
    case QLocale::Greek:
        return Greek;
    case QLocale::Gujarati:
        return Gujarati;
    case QLocale::Haitian:
        return HaitianCreole;
    case QLocale::Hausa:
        return Hausa;
    case QLocale::Hawaiian:
        return Hawaiian;
    case QLocale::Hebrew:
        return Hebrew;
    case QLocale::Hindi:
        return Hindi;
    case QLocale::HmongNjua:
        return Hmong;
    case QLocale::Hungarian:
        return Hungarian;
    case QLocale::Icelandic:
        return Icelandic;
    case QLocale::Igbo:
        return Igbo;
    case QLocale::Indonesian:
        return Indonesian;
    case QLocale::Irish:
        return Irish;
    case QLocale::Italian:
        return Italian;
    case QLocale::Japanese:
        return Japanese;
    case QLocale::Javanese:
        return Javanese;
    case QLocale::Kannada:
        return Kannada;
    case QLocale::Kazakh:
        return Kazakh;
    case QLocale::Khmer:
        return Khmer;
    case QLocale::Korean:
        return Korean;
    case QLocale::Kurdish:
        return Kurdish;
    case QLocale::Lao:
        return Lao;
    case QLocale::Latin:
        return Latin;
    case QLocale::Latvian:
        return Latvian;
    case QLocale::Lithuanian:
        return Lithuanian;
    case QLocale::Luxembourgish:
        return Luxembourgish;
    case QLocale::Macedonian:
        return Macedonian;
    case QLocale::Malagasy:
        return Malagasy;
    case QLocale::Malay:
        return Malay;
    case QLocale::Malayalam:
        return Malayalam;
    case QLocale::Maltese:
        return Maltese;
    case QLocale::Maori:
        return Maori;
    case QLocale::Marathi:
        return Marathi;
    case QLocale::Mongolian:
        return Mongolian;
    case QLocale::Nepali:
        return Nepali;
    case QLocale::Norwegian:
        return Norwegian;
    case QLocale::Pashto:
        return Pashto;
    case QLocale::Persian:
        return Persian;
    case QLocale::Polish:
        return Polish;
    case QLocale::Portuguese:
        return Portuguese;
    case QLocale::Punjabi:
        return Punjabi;
    case QLocale::Romanian:
        return Romanian;
    case QLocale::Russian:
        return Russian;
    case QLocale::Samoan:
        return Samoan;
    case QLocale::Gaelic:
        return ScotsGaelic;
    case QLocale::Serbian:
        return SerbianCyrillic;
    case QLocale::Shona:
        return Shona;
    case QLocale::Sindhi:
        return Sindhi;
    case QLocale::Sinhala:
        return Sinhala;
    case QLocale::Slovak:
        return Slovak;
    case QLocale::Slovenian:
        return Slovenian;
    case QLocale::Somali:
        return Somali;
    case QLocale::Spanish:
        return Spanish;
    case QLocale::Sundanese:
        return Sundanese;
    case QLocale::Swahili:
        return Swahili;
    case QLocale::Swedish:
        return Swedish;
    case QLocale::Filipino:
        return Filipino;
    case QLocale::Tajik:
        return Tajik;
    case QLocale::Tamil:
        return Tamil;
    case QLocale::Telugu:
        return Telugu;
    case QLocale::Thai:
        return Thai;
    case QLocale::Turkish:
        return Turkish;
    case QLocale::Ukrainian:
        return Ukrainian;
    case QLocale::Urdu:
        return Urdu;
    case QLocale::Uzbek:
        return Uzbek;
    case QLocale::Vietnamese:
        return Vietnamese;
    case QLocale::Welsh:
        return Welsh;
    case QLocale::Xhosa:
        return Xhosa;
    case QLocale::Yiddish:
        return Yiddish;
    case QLocale::Yoruba:
        return Yoruba;
    case QLocale::Zulu:
        return Zulu;
    default:
        return English;
    }
}

// Returns general language code
QOnlineTranslator::Language QOnlineTranslator::language(const QString &langCode)
{
    return s_languageCodes.key(langCode, NoLanguage);
}

bool QOnlineTranslator::isSupportTranslation(Engine engine, Language lang)
{
    bool isSupported = false;

    switch (engine) {
    case Google:
        switch (lang) {
        case NoLanguage:
        case Bashkir:
        case HillMari:
        case Mari:
        case Papiamento:
        case Tatar:
        case Udmurt:
        case Cantonese:
        case Fijian:
        case Filipino:
        case Georgian:
        case Klingon:
        case KlingonPlqaD:
        case LevantineArabic:
        case QueretaroOtomi:
        case SerbianLatin:
        case Tahitian:
        case Tongan:
        case YucatecMaya:
            isSupported = false;
            break;
        default:
            isSupported = true;
            break;
        }
        break;
    case Yandex:
        switch (lang) {
        case NoLanguage:
        case LevantineArabic:
        case Cantonese:
        case Corsican:
        case Fijian:
        case Filipino:
        case Frisian:
        case Igbo:
        case Hausa:
        case Hawaiian:
        case Klingon:
        case KlingonPlqaD:
        case Kurdish:
        case Chichewa:
        case Pashto:
        case QueretaroOtomi:
        case Samoan:
        case SerbianLatin:
        case Sesotho:
        case Shona:
        case Sindhi:
        case Somali:
        case Tahitian:
        case Tongan:
        case Yoruba:
        case YucatecMaya:
        case Zulu:
            isSupported = false;
            break;
        default:
            isSupported = true;
            break;
        }
        break;
    case Bing:
        switch (lang) {
        case NoLanguage:
        case Albanian:
        case Amharic:
        case Armenian:
        case Azerbaijani:
        case Basque:
        case Bashkir:
        case Belarusian:
        case Cebuano:
        case Corsican:
        case Esperanto:
        case Frisian:
        case Galician:
        case Georgian:
        case Gujarati:
        case Hausa:
        case Hawaiian:
        case HillMari:
        case Igbo:
        case Irish:
        case Javanese:
        case Kannada:
        case Kazakh:
        case Khmer:
        case Kurdish:
        case Kyrgyz:
        case Lao:
        case Latin:
        case Luxembourgish:
        case Macedonian:
        case Malayalam:
        case Maori:
        case Marathi:
        case Mari:
        case Mongolian:
        case Myanmar:
        case Nepali:
        case Chichewa:
        case Papiamento:
        case Pashto:
        case Punjabi:
        case ScotsGaelic:
        case Sesotho:
        case Shona:
        case Sindhi:
        case Sinhala:
        case Somali:
        case Sundanese:
        case Tagalog:
        case Tajik:
        case Tatar:
        case Udmurt:
        case Uzbek:
        case Xhosa:
        case Yiddish:
        case Yoruba:
        case Zulu:
            isSupported = false;
            break;
        default:
            isSupported = true;
            break;
        }
    }

    return isSupported;
}

void QOnlineTranslator::skipGarbageText()
{
    m_translation.append(sender()->property(s_textProperty).toString());
}

void QOnlineTranslator::requestGoogleTranslate()
{
    const QString sourceText = sender()->property(s_textProperty).toString();

    // Generate API url
    QUrl url("https://translate.googleapis.com/translate_a/single");
    url.setQuery("client=gtx&ie=UTF-8&oe=UTF-8&dt=bd&dt=ex&dt=ld&dt=md&dt=rw&dt=rm&dt=ss&dt=t&dt=at&dt=qc"
                 "&sl=" + languageApiCode(Google, m_sourceLang)
                 + "&tl=" + languageApiCode(Google, m_translationLang)
                 + "&hl=" + languageApiCode(Google, m_uiLang)
                 + "&q=" + QUrl::toPercentEncoding(sourceText));

    m_currentReply = m_networkManager->get(QNetworkRequest(url));
}

void QOnlineTranslator::parseGoogleTranslate()
{
    m_currentReply->deleteLater();

    // Check for error
    if (m_currentReply->error() != QNetworkReply::NoError) {
        if (m_currentReply->error() == QNetworkReply::ServiceUnavailableError)
            resetData(ServiceError, tr("Error: Engine systems have detected suspicious traffic from your computer network. Please try your request again later."));
        else
            resetData(NetworkError, m_currentReply->errorString());
        return;
    }

    // Check availability of service
    const QByteArray data = m_currentReply->readAll();
    if (data.startsWith('<')) {
        resetData(ServiceError, tr("Error: Engine systems have detected suspicious traffic from your computer network. Please try your request again later."));
        return;
    }

    // Read Json
    const QJsonDocument jsonResponse = QJsonDocument::fromJson(data);
    const QJsonArray jsonData = jsonResponse.array();

    if (m_sourceLang == Auto) {
        // Parse language
        m_sourceLang = language(Google, jsonData.at(2).toString());
        if (m_sourceLang == NoLanguage) {
            resetData(ParsingError, tr("Error: Unable to parse autodetected language"));
            return;
        }
        if (m_onlyDetectLanguage)
            return;
    }

    // Add a space between parts
    if (!m_translation.isEmpty() && !m_translation.endsWith('\n'))
        m_translation.append(' ');

    // Parse first sentense. If the answer contains more than one sentence, then at the end of the first one there will be a space
    const QJsonArray translationDataArray = jsonData.at(0).toArray();
    m_translation.append(translationDataArray.at(0).toArray().first().toString());
    for (int i = 1; m_translation.endsWith(' ') || m_translation.endsWith('\n') || m_translation.endsWith(0x00a0); ++i)
        m_translation.append(translationDataArray.at(i).toArray().first().toString());

    // Parse transliterations and source language
    if (m_translationTranslitEnabled) {
        if (!m_translationTranslit.isEmpty() && !m_translationTranslit.endsWith('\n'))
            m_translationTranslit.append(' ');
        m_translationTranslit.append(translationDataArray.last().toArray().at(2).toString());
    }

    if (m_sourceTranslitEnabled) {
        if (!m_sourceTranslit.isEmpty() && !m_sourceTranslit.endsWith('\n'))
            m_sourceTranslit.append(' ');
        m_sourceTranslit.append(translationDataArray.last().toArray().at(3).toString());
    }

    if (!m_translationOptionsEnabled || m_source.size() >= s_googleTranslateLimit)
        return;

    // Translation options
    for (const QJsonValueRef typeOfSpeechData : jsonData.at(1).toArray()) {
        const QJsonArray typeOfSpeechDataArray = typeOfSpeechData.toArray();
        const QString typeOfSpeech = typeOfSpeechDataArray.at(0).toString();
        for (const QJsonValueRef wordData : typeOfSpeechDataArray.at(2).toArray()) {
            const QJsonArray wordDataArray = wordData.toArray();
            const QString word = wordDataArray.at(0).toString();
            const QString gender = wordDataArray.at(4).toString();
            QStringList translations;
            for (const QJsonValueRef wordTranslation : wordDataArray.at(1).toArray())
                translations.append(wordTranslation.toString());
            m_translationOptions[typeOfSpeech].append({word, gender, translations});
        }
    }

    // Examples
    if (m_translationOptionsEnabled) {
        for (const QJsonValueRef exampleData : jsonData.at(12).toArray()) {
            const QJsonArray exampleDataArray = exampleData.toArray();
            const QString typeOfSpeech = exampleDataArray.at(0).toString();
            const QJsonArray example = exampleDataArray.at(1).toArray().first().toArray();

            m_examples[typeOfSpeech].append({example.at(2).toString(), example.at(0).toString()});
        }
    }
}

void QOnlineTranslator::requestYandexKey()
{
    const QUrl url("https://translate.yandex.com/");
    m_currentReply = m_networkManager->get(QNetworkRequest(url));
}

void QOnlineTranslator::parseYandexKey()
{
    m_currentReply->deleteLater();

    if (m_currentReply->error() != QNetworkReply::NoError) {
        resetData(NetworkError, m_currentReply->errorString());
        return;
    }

    // Check availability of service
    const QByteArray webSiteData = m_currentReply->readAll();
    if (webSiteData.contains("<title>Oops!</title>") || webSiteData.contains("<title>302 Found</title>")) {
        resetData(ServiceError, tr("Error: Engine systems have detected suspicious traffic from your computer network. Please try your request again later."));
        return;
    }

    // Parse SID
    const QString sid = webSiteData.mid(webSiteData.indexOf("SID: '") + 6, 26);

    // Yandex show reversed parts of session ID, need to decode
    QStringList sidParts = sid.split('.');
    for (short i = 0; i < sidParts.size(); ++i)
        std::reverse(sidParts[i].begin(), sidParts[i].end());

    s_yandexKey = sidParts.join('.');
    if (s_yandexKey.isEmpty()) {
        resetData(ParsingError, tr("Error: Unable to parse Yandex SID."));
        return;
    }
}

void QOnlineTranslator::requestYandexTranslate()
{
    const QString sourceText = sender()->property(s_textProperty).toString();

    QString lang;
    if (m_sourceLang == Auto)
        lang = languageApiCode(Yandex, m_translationLang);
    else
        lang = languageApiCode(Yandex, m_sourceLang) + '-' + languageApiCode(Yandex, m_translationLang);

    // Generate API url
    QUrl url("https://translate.yandex.net/api/v1/tr.json/translate");
    url.setQuery("id="
                 + s_yandexKey
                 + "-0-0&srv=tr-text&text="
                 + QUrl::toPercentEncoding(sourceText)
                 + "&lang="
                 + lang);

    m_currentReply = m_networkManager->get(QNetworkRequest(url));
}

void QOnlineTranslator::parseYandexTranslate()
{
    m_currentReply->deleteLater();

    // Check for errors
    if (m_currentReply->error() != QNetworkReply::NoError) {
        // Network errors
        if (m_currentReply->error() < QNetworkReply::ContentAccessDenied) {
            resetData(NetworkError, m_currentReply->errorString());
            return;
        }

        // Parse data to get request error type
        s_yandexKey.clear();
        const QJsonDocument jsonResponse = QJsonDocument::fromJson(m_currentReply->readAll());
        resetData(ServiceError, jsonResponse.object().value("message").toString());
        return;
    }

    // Read Json
    const QJsonDocument jsonResponse = QJsonDocument::fromJson(m_currentReply->readAll());
    const QJsonObject jsonData = jsonResponse.object();

    // Parse language
    if (m_sourceLang == Auto) {
        QString sourceCode = jsonData.value("lang").toString();
        sourceCode = sourceCode.left(sourceCode.indexOf('-'));
        m_sourceLang = language(Yandex, sourceCode);
        if (m_sourceLang == NoLanguage) {
            resetData(ParsingError, tr("Error: Unable to parse autodetected language"));
            return;
        }
        if (m_onlyDetectLanguage)
            return;
    }

    // Parse translation data
    m_translation += jsonData.value("text").toArray().at(0).toString();
}

void QOnlineTranslator::requestYandexSourceTranslit()
{
    requestYandexTranslit(m_sourceLang);
}

void QOnlineTranslator::parseYandexSourceTranslit()
{
    parseYandexTranslit(m_sourceTranslit);
}

void QOnlineTranslator::requestYandexTranslationTranslit()
{
    requestYandexTranslit(m_translationLang);
}

void QOnlineTranslator::parseYandexTranslationTranslit()
{
    parseYandexTranslit(m_translationTranslit);
}

void QOnlineTranslator::requestYandexDictionary()
{
    // Check if language is supported (need to check here because language may be autodetected)
    if (!isSupportDictionary(Yandex, m_sourceLang, m_translationLang) && !m_source.contains(' ')) {
        auto *state = qobject_cast<QState *>(sender());
        state->addTransition(new QFinalState(state->parentState()));
        return;
    }

    // Generate API url
    const QString text = sender()->property(s_textProperty).toString();
    QUrl url("http://dictionary.yandex.net/dicservice.json/lookupMultiple");
    url.setQuery("text=" + QUrl::toPercentEncoding(text)
                 + "&ui=" + languageApiCode(Yandex, m_uiLang)
                 + "&dict=" + languageApiCode(Yandex, m_sourceLang) + '-' + languageApiCode(Yandex, m_translationLang));

    m_currentReply = m_networkManager->get(QNetworkRequest(url));
}

void QOnlineTranslator::parseYandexDictionary()
{
    m_currentReply->deleteLater();

    if (m_currentReply->error() != QNetworkReply::NoError) {
        resetData(NetworkError, m_currentReply->errorString());
        return;
    }

    // Parse reply
    const QJsonDocument jsonResponse = QJsonDocument::fromJson(m_currentReply->readAll());
    const QJsonValue jsonData = jsonResponse.object().value(languageApiCode(Yandex, m_sourceLang) + '-' + languageApiCode(Yandex, m_translationLang)).toObject().value("regular");

    if (m_sourceTranscriptionEnabled)
        m_sourceTranscription = jsonData.toArray().at(0).toObject().value("ts").toString();

    for (const QJsonValueRef typeOfSpeechData : jsonData.toArray()) {
        QJsonObject typeOfSpeechObject = typeOfSpeechData.toObject();
        const QString typeOfSpeech = typeOfSpeechObject.value("pos").toObject().value("text").toString();
        for (const QJsonValueRef wordData : typeOfSpeechObject.value("tr").toArray()) {
            // Parse translation options
            const QJsonObject wordObject = wordData.toObject();
            const QString word = wordObject.value("text").toString();
            const QString gender = wordObject.value("gen").toObject().value("text").toString();
            QStringList translations;
            for (const QJsonValueRef wordTranslation : wordObject.value("mean").toArray())
                translations.append(wordTranslation.toObject().value("text").toString());

            m_translationOptions[typeOfSpeech].append({word, gender, translations});

            // Parse examples
            if (m_examplesEnabled && wordObject.contains("ex")) {
                for (const QJsonValueRef exampleData : wordObject.value("ex").toArray()) {
                    const QJsonObject exampleObject = exampleData.toObject();
                    const QString example = exampleObject.value("text").toString();
                    const QString description = exampleObject.value("tr").toArray().first().toObject().value("text").toString();

                    m_examples[typeOfSpeech].append({example, description});
                }
            }
        }
    }
}

void QOnlineTranslator::requestBingTranslate()
{
    const QString sourceText = sender()->property(s_textProperty).toString();

    // Generate POST data
    const QByteArray postData = "&text=" + sourceText.toLocal8Bit()
            + "&fromLang=" + languageApiCode(Bing, m_sourceLang).toLocal8Bit()
            + "&to=" + languageApiCode(Bing, m_translationLang).toLocal8Bit();
    const QUrl url("http://www.bing.com/ttranslatev3");

    // Setup request
    QNetworkRequest request;
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/x-www-form-urlencoded");
    request.setHeader(QNetworkRequest::ContentLengthHeader, postData.size());
    request.setUrl(url);

    // Make reply
    m_currentReply = m_networkManager->post(request, postData);
}

void QOnlineTranslator::parseBingTranslate()
{
    m_currentReply->deleteLater();

    // Check for errors
    if (m_currentReply->error() != QNetworkReply::NoError) {
        resetData(NetworkError, m_currentReply->errorString());
        return;
    }

    // Parse translation data
    const QJsonDocument jsonResponse = QJsonDocument::fromJson(m_currentReply->readAll());
    const QJsonObject responseObject = jsonResponse.array().first().toObject();

    if (m_sourceLang == Auto) {
        const QString langCode = responseObject.value("detectedLanguage").toObject().value("language").toString();
        m_sourceLang = language(Bing, langCode);
        if (m_sourceLang == NoLanguage) {
            resetData(ParsingError, tr("Error: Unable to parse autodetected language"));
            return;
        }
        if (m_onlyDetectLanguage)
            return;
    }

    const QJsonObject translationsObject = responseObject.value("translations").toArray().first().toObject();
    m_translation += translationsObject.value("text").toString();
    m_translationTranslit += translationsObject.value("transliteration").toObject().value("text").toString();
}

void QOnlineTranslator::requestBingDictionary()
{
    // Check if language is supported (need to check here because language may be autodetected)
    if (!isSupportDictionary(Bing, m_sourceLang, m_translationLang) && !m_source.contains(' ')) {
        auto *state = qobject_cast<QState *>(sender());
        state->addTransition(new QFinalState(state->parentState()));
        return;
    }

    // Generate POST data
    const QString text = sender()->property(s_textProperty).toString();
    const QByteArray postData = "&text=" + text.toLocal8Bit()
            + "&from=" + languageApiCode(Bing, m_sourceLang).toLocal8Bit()
            + "&to=" + languageApiCode(Bing, m_translationLang).toLocal8Bit();
    const QUrl url("http://www.bing.com/tlookupv3");

    QNetworkRequest request;
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/x-www-form-urlencoded");
    request.setHeader(QNetworkRequest::ContentLengthHeader, postData.size());
    request.setUrl(url);

    m_currentReply = m_networkManager->post(request, postData);
}

void QOnlineTranslator::parseBingDictionary()
{
    m_currentReply->deleteLater();

    // Check for errors
    if (m_currentReply->error() != QNetworkReply::NoError) {
        resetData(NetworkError, m_currentReply->errorString());
        return;
    }

    const QJsonDocument jsonResponse = QJsonDocument::fromJson(m_currentReply->readAll());
    const QJsonObject responseObject = jsonResponse.array().first().toObject();

    for (const QJsonValueRef dictionaryData : responseObject.value("translations").toArray()) {
        const QJsonObject dictionaryObject = dictionaryData.toObject();
        const QString typeOfSpeech = dictionaryObject.value("posTag").toString().toLower();
        const QString word = dictionaryObject.value("displayTarget").toString().toLower();
        QStringList translations;
        for (const QJsonValueRef wordTranslation : dictionaryObject.value("backTranslations").toArray())
            translations.append(wordTranslation.toObject().value("displayText").toString());

        m_translationOptions[typeOfSpeech].append({word, {}, translations});
    }
}

void QOnlineTranslator::buildGoogleStateMachine()
{
    // States (Google sends translation, translit and dictionary in one request, that will be splitted into several by the translation limit)
    auto *translationState = new QState(m_stateMachine);
    auto *finalState = new QFinalState(m_stateMachine);
    m_stateMachine->setInitialState(translationState);

    translationState->addTransition(translationState, &QState::finished, finalState);

    // Setup translation state
    buildSplitNetworkRequest(translationState, &QOnlineTranslator::requestGoogleTranslate, &QOnlineTranslator::parseGoogleTranslate, m_source, s_googleTranslateLimit);
}

void QOnlineTranslator::buildGoogleDetectStateMachine()
{
    // States
    auto *detectState = new QState(m_stateMachine);
    auto *finalState = new QFinalState(m_stateMachine);
    m_stateMachine->setInitialState(detectState);

    detectState->addTransition(detectState, &QState::finished, finalState);

    // Setup detect state
    const QString text = m_source.left(getSplitIndex(m_source, s_googleTranslateLimit));
    buildNetworkRequestState(detectState, &QOnlineTranslator::requestGoogleTranslate, &QOnlineTranslator::parseGoogleTranslate, text);
}

void QOnlineTranslator::buildYandexStateMachine()
{
    // States
    auto *keyState = new QState(m_stateMachine); // Generate session ID first to access API (Required for Yandex)
    auto *translationState = new QState(m_stateMachine);
    auto *sourceTranslitState = new QState(m_stateMachine);
    auto *translationTranslitState = new QState(m_stateMachine);
    auto *dictionaryState = new QState(m_stateMachine);
    auto *finalState = new QFinalState(m_stateMachine);
    m_stateMachine->setInitialState(keyState);

    // Transitions
    keyState->addTransition(keyState, &QState::finished, translationState);
    translationState->addTransition(translationState, &QState::finished, sourceTranslitState);
    sourceTranslitState->addTransition(sourceTranslitState, &QState::finished, translationTranslitState);
    translationTranslitState->addTransition(translationTranslitState, &QState::finished, dictionaryState);
    dictionaryState->addTransition(dictionaryState, &QState::finished, finalState);

    // Setup key state
    if (s_yandexKey.isEmpty())
        buildNetworkRequestState(keyState, &QOnlineTranslator::requestYandexKey, &QOnlineTranslator::parseYandexKey);
    else
        keyState->setInitialState(new QFinalState(keyState));

    // Setup translation state
    buildSplitNetworkRequest(translationState, &QOnlineTranslator::requestYandexTranslate, &QOnlineTranslator::parseYandexTranslate, m_source, s_yandexTranslateLimit);

    // Setup source translit state
    if (m_sourceTranslitEnabled)
        buildSplitNetworkRequest(sourceTranslitState, &QOnlineTranslator::requestYandexSourceTranslit, &QOnlineTranslator::parseYandexSourceTranslit, m_source, s_yandexTranslitLimit);
    else
        sourceTranslitState->setInitialState(new QFinalState(sourceTranslitState));

    // Setup translation translit state
    if (m_translationTranslitEnabled)
        buildSplitNetworkRequest(translationTranslitState, &QOnlineTranslator::requestYandexTranslationTranslit, &QOnlineTranslator::parseYandexTranslationTranslit, m_translation, s_yandexTranslitLimit);
    else
        translationTranslitState->setInitialState(new QFinalState(translationTranslitState));

    // Setup dictionary state
    if (m_translationOptionsEnabled)
        buildNetworkRequestState(dictionaryState, &QOnlineTranslator::requestYandexDictionary, &QOnlineTranslator::parseYandexDictionary, m_source);
    else
        dictionaryState->setInitialState(new QFinalState(dictionaryState));
}

void QOnlineTranslator::buildYandexDetectStateMachine()
{
    // States
    auto *keyState = new QState(m_stateMachine); // Generate session ID first to access API (Required for Yandex)
    auto *detectState = new QState(m_stateMachine);
    auto *finalState = new QFinalState(m_stateMachine);
    m_stateMachine->setInitialState(keyState);

    // Transitions
    keyState->addTransition(keyState, &QState::finished, detectState);
    detectState->addTransition(detectState, &QState::finished, finalState);

    // Setup key state
    if (s_yandexKey.isEmpty())
        buildNetworkRequestState(keyState, &QOnlineTranslator::requestYandexKey, &QOnlineTranslator::parseYandexKey);
    else
        keyState->setInitialState(new QFinalState(keyState));

    // Setup detect state
    const QString text = m_source.left(getSplitIndex(m_source, s_yandexTranslateLimit));
    buildNetworkRequestState(detectState, &QOnlineTranslator::requestYandexTranslate, &QOnlineTranslator::parseYandexTranslate, text);
}

void QOnlineTranslator::buildBingStateMachine()
{
    // States
    auto *translationState = new QState(m_stateMachine);
    auto *dictionaryState = new QState(m_stateMachine);
    auto *finalState = new QFinalState(m_stateMachine);
    m_stateMachine->setInitialState(translationState);

    // Transitions
    translationState->addTransition(translationState, &QState::finished, dictionaryState);
    dictionaryState->addTransition(dictionaryState, &QState::finished, finalState);

    // Setup translation state
    buildSplitNetworkRequest(translationState, &QOnlineTranslator::requestBingTranslate, &QOnlineTranslator::parseBingTranslate, m_source, s_bingTranslateLimit);

    // Setup dictionary state
    if (m_translationOptionsEnabled)
        buildNetworkRequestState(dictionaryState, &QOnlineTranslator::requestBingDictionary, &QOnlineTranslator::parseBingDictionary, m_source);
    else
        dictionaryState->setInitialState(new QFinalState(dictionaryState));
}

void QOnlineTranslator::buildBingDetectStateMachine()
{
    // States
    auto *detectState = new QState(m_stateMachine);
    auto *finalState = new QFinalState(m_stateMachine);
    m_stateMachine->setInitialState(detectState);

    detectState->addTransition(detectState, &QState::finished, finalState);

    // Setup translation state
    const QString text = m_source.left(getSplitIndex(m_source, s_bingTranslateLimit));
    buildNetworkRequestState(detectState, &QOnlineTranslator::requestBingTranslate, &QOnlineTranslator::parseBingTranslate, text);
}

void QOnlineTranslator::buildSplitNetworkRequest(QState *parent, void (QOnlineTranslator::*requestMethod)(), void (QOnlineTranslator::*parseMethod)(), const QString &text, int textLimit)
{
    QString unsendedText = text;
    auto *nextTranslationState = new QState(parent);
    parent->setInitialState(nextTranslationState);

    while (!unsendedText.isEmpty()) {
        auto *currentTranslationState = nextTranslationState;
        nextTranslationState = new QState(parent);

        // Do not translate the part if it looks like garbage
        const int splitIndex = getSplitIndex(unsendedText, textLimit);
        if (splitIndex == -1) {
            currentTranslationState->setProperty(s_textProperty, unsendedText.left(textLimit));
            currentTranslationState->addTransition(nextTranslationState);
            connect(currentTranslationState, &QState::entered, this, &QOnlineTranslator::skipGarbageText);

            // Remove the parsed part from the next parsing
            unsendedText = unsendedText.mid(textLimit);
        } else {
            buildNetworkRequestState(currentTranslationState, requestMethod, parseMethod, unsendedText.left(splitIndex));
            currentTranslationState->addTransition(currentTranslationState, &QState::finished, nextTranslationState);

            // Remove the parsed part from the next parsing
            unsendedText = unsendedText.mid(splitIndex);
        }
    }

    nextTranslationState->addTransition(new QFinalState(parent));
}

void QOnlineTranslator::buildNetworkRequestState(QState *parent, void (QOnlineTranslator::*requestMethod)(), void (QOnlineTranslator::*parseMethod)(), const QString &text)
{
    // Network substates
    auto *requestingState = new QState(parent);
    auto *parsingState = new QState(parent);

    parent->setInitialState(requestingState);

    // Substates transitions
    requestingState->addTransition(m_networkManager, &QNetworkAccessManager::finished, parsingState);
    parsingState->addTransition(new QFinalState(parent));

    // Setup requesting state
    requestingState->setProperty(s_textProperty, text);
    connect(requestingState, &QState::entered, this, requestMethod);

    // Setup parsing state
    connect(parsingState, &QState::entered, this, parseMethod);
}

void QOnlineTranslator::requestYandexTranslit(Language language)
{
    // Check if language is supported (need to check here because language may be autodetected)
    if (!isSupportTranslit(Yandex, language)) {
        auto *state = qobject_cast<QState *>(sender());
        state->addTransition(new QFinalState(state->parentState()));
        return;
    }

    const QString text = sender()->property(s_textProperty).toString();

    // Generate API url
    QUrl url("https://translate.yandex.net/translit/translit");
    url.setQuery("text=" + QUrl::toPercentEncoding(text)
                 + "&lang=" + languageApiCode(Yandex, language));

    m_currentReply = m_networkManager->get(QNetworkRequest(url));
}

void QOnlineTranslator::parseYandexTranslit(QString &text)
{
    m_currentReply->deleteLater();

    if (m_currentReply->error() != QNetworkReply::NoError) {
        resetData(NetworkError, m_currentReply->errorString());
        return;
    }

    const QByteArray reply = m_currentReply->readAll();

#if QT_VERSION >= QT_VERSION_CHECK(5, 10, 0)
        text += reply.mid(1).chopped(1);
#else
        text += reply.mid(1);
        text.chop(1);
#endif
}

void QOnlineTranslator::resetData(TranslationError error, const QString &errorString)
{
    m_error = error;
    m_errorString = errorString;
    m_translation.clear();
    m_translationTranslit.clear();
    m_sourceTranslit.clear();
    m_sourceTranscription.clear();
    m_translationOptions.clear();
    m_examples.clear();

    if (m_error != NoError)
        emit this->error(m_error);

    m_stateMachine->stop();
    for (QAbstractState *state : m_stateMachine->findChildren<QAbstractState *>()) {
        if (!m_stateMachine->configuration().contains(state))
            state->deleteLater();
    }
}

bool QOnlineTranslator::isSupportTranslit(Engine engine, Language lang)
{
    switch (engine) {
    case Google:
        isSupportTranslation(Google, lang); // Google supports transliteration for all supported languages
        break;
    case Yandex:
        switch (lang) {
        case Amharic:
        case Armenian:
        case Bengali:
        case SimplifiedChinese:
        case Georgian:
        case Greek:
        case Gujarati:
        case Hebrew:
        case Hindi:
        case Japanese:
        case Kannada:
        case Korean:
        case Malayalam:
        case Marathi:
        case Nepali:
        case Punjabi:
        case Russian:
        case Sinhala:
        case Tamil:
        case Telugu:
        case Thai:
        case Yiddish:
            return true;
        default:
            return false;
        }
    case Bing:
        switch (lang) {
        case Arabic:
        case Bengali:
        case Gujarati:
        case Hebrew:
        case Hindi:
        case Japanese:
        case Kannada:
        case Malayalam:
        case Marathi:
        case Punjabi:
        case SerbianCyrillic:
        case SerbianLatin:
        case Tamil:
        case Telugu:
        case Thai:
        case SimplifiedChinese:
        case TraditionalChinese:
            return true;
        default:
            return false;
        }
    }

    return false;
}

bool QOnlineTranslator::isSupportDictionary(Engine engine, Language sourceLang, Language translationLang)
{
    switch (engine) {
    case Google:
        return isSupportTranslation(Google, sourceLang) && isSupportTranslation(Google, translationLang); // Google supports dictionary for all supported languages
    case Yandex:
        switch (sourceLang) {
        case Belarusian:
            switch (translationLang) {
            case Belarusian:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case Bulgarian:
            switch (translationLang) {
            case Russian:
                return true;
            default:
                return false;
            }
        case Czech:
            switch (translationLang) {
            case English:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case Danish:
            switch (translationLang) {
            case English:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case German:
            switch (translationLang) {
            case German:
                return true;
            case English:
                return true;
            case Russian:
                return true;
            case Turkish:
                return true;
            default:
                return false;
            }
        case Greek:
            switch (translationLang) {
            case English:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case English:
            switch (translationLang) {
            case Czech:
                return true;
            case Danish:
                return true;
            case German:
                return true;
            case Greek:
                return true;
            case English:
                return true;
            case Spanish:
                return true;
            case Estonian:
                return true;
            case Finnish:
                return true;
            case French:
                return true;
            case Italian:
                return true;
            case Lithuanian:
                return true;
            case Latvian:
                return true;
            case Dutch:
                return true;
            case Norwegian:
                return true;
            case Portuguese:
                return true;
            case Russian:
                return true;
            case Slovak:
                return true;
            case Swedish:
                return true;
            case Turkish:
                return true;
            case Ukrainian:
                return true;
            default:
                return false;
            }
        case Spanish:
            switch (translationLang) {
            case English:
                return true;
            case Spanish:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case Estonian:
            switch (translationLang) {
            case English:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case Finnish:
            switch (translationLang) {
            case English:
                return true;
            case Russian:
                return true;
            case Finnish:
                return true;
            default:
                return false;
            }
        case French:
            switch (translationLang) {
            case French:
                return true;
            case English:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case Hungarian:
            switch (translationLang) {
            case Hungarian:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case Italian:
            switch (translationLang) {
            case English:
                return true;
            case Italian:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case Lithuanian:
            switch (translationLang) {
            case English:
                return true;
            case Lithuanian:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case Latvian:
            switch (translationLang) {
            case English:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case Mari:
            switch (translationLang) {
            case Russian:
                return true;
            default:
                return false;
            }
        case HillMari:
            switch (translationLang) {
            case Russian:
                return true;
            default:
                return false;
            }
        case Dutch:
            switch (translationLang) {
            case English:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case Norwegian:
            switch (translationLang) {
            case English:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case Polish:
            switch (translationLang) {
            case Russian:
                return true;
            default:
                return false;
            }
        case Portuguese:
            switch (translationLang) {
            case English:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case Russian:
            switch (translationLang) {
            case Belarusian:
                return true;
            case Bulgarian:
                return true;
            case Czech:
                return true;
            case Danish:
                return true;
            case German:
                return true;
            case Greek:
                return true;
            case English:
                return true;
            case Spanish:
                return true;
            case Estonian:
                return true;
            case Finnish:
                return true;
            case French:
                return true;
            case Italian:
                return true;
            case Lithuanian:
                return true;
            case Latvian:
                return true;
            case Mari:
                return true;
            case HillMari:
                return true;
            case Dutch:
                return true;
            case Norwegian:
                return true;
            case Portuguese:
                return true;
            case Russian:
                return true;
            case Slovak:
                return true;
            case Swedish:
                return true;
            case Turkish:
                return true;
            case Tatar:
                return true;
            case Ukrainian:
                return true;
            default:
                return false;
            }
        case Slovak:
            switch (translationLang) {
            case English:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case Swedish:
            switch (translationLang) {
            case English:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case Turkish:
            switch (translationLang) {
            case German:
                return true;
            case English:
                return true;
            case Russian:
                return true;
            default:
                return false;
            }
        case Tatar:
            switch (translationLang) {
            case Russian:
                return true;
            default:
                return false;
            }
        case Ukrainian:
            switch (translationLang) {
            case English:
                return true;
            case Russian:
                return true;
            case Ukrainian:
                return true;
            default:
                return false;
            }
        default:
            return false;
        }
    case Bing:
        // Bing support dictionary only to or from English
        Language secondLang;
        if (sourceLang == English)
            secondLang = translationLang;
        else if (translationLang == English)
            secondLang = sourceLang;
        else
            return false;

        switch (secondLang) {
        case Afrikaans:
        case Arabic:
        case Bengali:
        case Bosnian:
        case Bulgarian:
        case Catalan:
        case SimplifiedChinese:
        case Croatian:
        case Czech:
        case Danish:
        case Dutch:
        case Estonian:
        case Finnish:
        case French:
        case German:
        case Greek:
        case HaitianCreole:
        case Hebrew:
        case Hindi:
        case Hmong:
        case Hungarian:
        case Icelandic:
        case Indonesian:
        case Italian:
        case Japanese:
        case Swahili:
        case Klingon:
        case Korean:
        case Latvian:
        case Lithuanian:
        case Malay:
        case Maltese:
        case Norwegian:
        case Persian:
        case Polish:
        case Portuguese:
        case Romanian:
        case Russian:
        case SerbianLatin:
        case Slovak:
        case Slovenian:
        case Spanish:
        case Swedish:
        case Tamil:
        case Thai:
        case Turkish:
        case Ukrainian:
        case Urdu:
        case Vietnamese:
        case Welsh:
            return true;
        default:
            return false;
        }
    }

    return false;
}

// Returns engine-specific language code for translation
QString QOnlineTranslator::languageApiCode(Engine engine, Language lang)
{
    if (!isSupportTranslation(engine, lang))
        return QString();

    // Engines have some language codes exceptions
    switch (engine) {
    case Google:
        if (lang == SerbianCyrillic)
            return "sr";
        break;
    case Yandex:
        switch (lang) {
        case SimplifiedChinese:
            return "zn";
        case Javanese:
            return "jv";
        case SerbianCyrillic:
            return "sr";
        default:
            break;
        }
        break;
    case Bing:
        switch (lang) {
        case Auto:
            return "auto-detect";
        case Bosnian:
            return "bs-Latn";
        case SimplifiedChinese:
            return "zh-Hans";
        case TraditionalChinese:
            return "zh-Hant";
        case Hmong:
            return "mww";
        default:
            break;
        }
        break;
    }

    // General case
    return s_languageCodes.value(lang);
}

// Parse language from response language code
QOnlineTranslator::Language QOnlineTranslator::language(Engine engine, const QString &langCode)
{
    // Engine exceptions
    switch (engine) {
    case Google:
        if (langCode == "sr")
            return SerbianCyrillic;
        break;
    case Yandex:
        if (langCode == "sr")
            return SerbianCyrillic;
        if (langCode == "zn")
            return SimplifiedChinese;
        if (langCode == "jv")
            return Javanese;
        break;
    case Bing:
        if (langCode == "zh-Hans")
            return SimplifiedChinese;
        if (langCode == "zh-Hant")
            return TraditionalChinese;
        if (langCode == "mww")
            return Hmong;
        break;
    }

    // General case
    return s_languageCodes.key(langCode, NoLanguage);
}

// Get split index of the text according to the limit
int QOnlineTranslator::getSplitIndex(const QString &untranslatedText, int limit)
{
    if (untranslatedText.size() < limit)
        return limit;

    int splitIndex = untranslatedText.lastIndexOf(". ", limit - 1);
    if (splitIndex != -1)
        return splitIndex + 1;

    splitIndex = untranslatedText.lastIndexOf(' ', limit - 1);
    if (splitIndex != -1)
        return splitIndex + 1;

    splitIndex = untranslatedText.lastIndexOf('\n', limit - 1);
    if (splitIndex != -1)
        return splitIndex + 1;

    // Non-breaking space
    splitIndex = untranslatedText.lastIndexOf(0x00a0, limit - 1);
    if (splitIndex != -1)
        return splitIndex + 1;

    // If the text has not passed any check and is most likely garbage
    return limit;
}

bool QOnlineTranslator::isExamplesEnabled() const
{
    return m_examplesEnabled;
}

void QOnlineTranslator::setExamplesEnabled(bool enable)
{
    m_examplesEnabled = enable;
}

bool QOnlineTranslator::isTranslationOptionsEnabled() const
{
    return m_translationOptionsEnabled;
}

void QOnlineTranslator::setTranslationOptionsEnabled(bool enable)
{
    m_translationOptionsEnabled = enable;
}

bool QOnlineTranslator::isSourceTranscriptionEnabled() const
{
    return m_sourceTranscriptionEnabled;
}

void QOnlineTranslator::setSourceTranscriptionEnabled(bool enable)
{
    m_sourceTranscriptionEnabled = enable;
}

bool QOnlineTranslator::isTranslationTranslitEnabled() const
{
    return m_translationTranslitEnabled;
}

void QOnlineTranslator::setTranslationTranslitEnabled(bool enable)
{
    m_translationTranslitEnabled = enable;
}

bool QOnlineTranslator::isSourceTranslitEnabled() const
{
    return m_sourceTranslitEnabled;
}

void QOnlineTranslator::setSourceTranslitEnabled(bool enable)
{
    m_sourceTranslitEnabled = enable;
}
